package com.samsung.android.simplehealth;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class WeightDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_details);
    }
}
