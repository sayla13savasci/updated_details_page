package com.samsung.android.simplehealth;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class GlucoseDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_glucose_details);
    }
}
